import Login from './login/Login';
import Dashboard from './dashboard/Dashboard';

export { Login, Dashboard };