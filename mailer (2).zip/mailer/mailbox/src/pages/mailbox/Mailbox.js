import { React, useEffect, useState, createRef } from "react";
import "../mailbox/Mailbox.scss";
import axios from "axios";
import { AiFillDelete } from "react-icons/ai";

const Mailbox = () => {
  const [mails, setMails] = useState([]);
  const titleRef = createRef();
  const contentRef = createRef();
  const receiverRef = createRef();

  const sendMailHandler = async (e) => {
    e.preventDefault();

    const title = titleRef.current.value,
      content = contentRef.current.value,
      receiver = receiverRef.current.value;

    if (title.length < 3 || content.length < 3 || receiver.length < 3) {
      return;
    }

    const data = { title, content, receiver };

    console.log(data);

    const getMails = async () => {
      const response = await axios.get(
        "/api/get/mails?token=" + sessionStorage.getItem("token")
      );

      if (response.data.success) {
        setMails(response.data.mails);
      }
    };

    useEffect(() => {
      getMails();
    }, []);

    const deleteMail = async (id) => {
      const response = await axios.delete(
        "/api/delete/mail/" + id + "?token=" + sessionStorage.getItem("token")
      );

      if (response.data.success) {
        getMails();
      }
    };

    return (
      <div className="sidebar">
        <div className="sidebar__header">
          <h3>Mailbox</h3>
        </div>
        <div className="sidebar__search">
          <div className="sidebar__searchContainer"></div>
        </div>
        <div className="sidebar__chats">
          <div className="sidebar__chatsContainer">
            {mails.map((mail) => (
              <div className="sidebar__chat" key={mail._id}>
                <div className="sidebar__chatInfo">
                  <h2>{mail.title}</h2>
                  <p>{mail.content}</p>
                </div>
                <div className="sidebar__chatIcons">
                  <button onClick={() => deleteMail(mail._id)}>
                    <AiFillDelete />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="sidebar__footer">
          <div className="sidebar__footerContainer">
            <form id="form" onSubmit={sendMailHandler}>
              <input type="text" placeholder="Title" ref={titleRef} required />
              <input
                type="text"
                placeholder="Content"
                ref={contentRef}
                required
              />
              <input
                type="text"
                placeholder="Receiver"
                ref={receiverRef}
                required
              />
              <button type="submit">Send</button>
            </form>
          </div>
        </div>
      </div>
    );
  };
};
export default Mailbox;
