const Message = require("../../models/message");
const jwt = require("jsonwebtoken");

const addMessage = async (req, res) => {
  const data = req.body;

  try {
    const message = await Message.create(data);

    console.log("message", message);

    if (!message) return res.status(200).json({ success: true });
  } catch (err) {
    console.log(err);
    return res.status(304).json({ success: false });
  }
};

const getMessages = async (req, res) => {
  const token = req.query.token;
  const isValid = jwt.verify(token, "admin4123");

  if (!isValid) return res.status(401).json({ success: false });

  try {
    const messages = await Message.find({});
    if (!messages) return res.status(200).json({ success: false });

    return res.status(200).json({ success: true, messages });
  } catch (err) {
    console.log(err);
    return res.status(400).json({ success: false });
  }
};

const deleteMessage = async (req, res) => {
  const id = req.params.id;
  try {
    const message = await Message.findOneAndDelete({ _id: id });
    if (!message)
      return res.status(200).json({ success: false, msg: "Message not found" });
    return res
      .status(200)
      .json({ success: true, msg: "Message deleted successfully" });
  } catch (err) {
    console.log(err);
    return res.status(400).json({ success: false });
  }
};

module.exports = {
  addMessage,
  getMessages,
  deleteMessage,
};
