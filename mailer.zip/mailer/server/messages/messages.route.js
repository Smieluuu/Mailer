const express = require("express");
const router = express.Router();
const userService = require("./service/messages");

router.post("/api/messages/add", userService.addMessage);
router.get("/api/messages/get", userService.getMessages);
router.delete("/api/messages/delete/:id", userService.deleteMessage);

module.exports = router;
