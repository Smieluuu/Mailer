const express = require("express");
const router = express.Router();
const userService = require("./service/messages");

router.post("/api/add/message", userService.addMessage);
router.get("/api/get/messages", userService.getMessages);
router.delete("/api/delete/message/:id", userService.deleteMessage);

module.exports = router;
