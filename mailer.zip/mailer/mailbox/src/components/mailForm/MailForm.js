import React from "react";
import "./Sidebar.scss";

const MailForm = () => {
  return <h1>MailForm</h1>;
};

export default MailForm;
