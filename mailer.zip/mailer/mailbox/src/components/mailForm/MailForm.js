// import React, { useRef, useState, useEffect } from "react";
// import axios from "axios";

// const MailForm = () => {
//   const nameRef = useRef(null);
//   const messageRef = useRef(null);
//   const [users, setUsers] = useState([]);
//   const [selectedUser, setSelectedUser] = useState("");

//   // useEffect(() => {
//   //   axios
//   //     .get("/api/get/users")
//   //     .then((response) => {
//   //       if (response.data.success) {
//   //         setUsers(response.data.users);
//   //       }
//   //     })
//   //     .catch((error) => {
//   //       console.error(error);
//   //     });
//   // }, []);

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     const name = nameRef.current.value;
//     const message = messageRef.current.value;
//     console.log(name, selectedUser.email, message);
//   };

//   return (
//     <form onSubmit={handleSubmit}>
//       <div>
//         <label htmlFor="name">Name:</label>
//         <input type="text" id="name" ref={nameRef} />
//       </div>
//       <div>
//         <label htmlFor="email">Email:</label>
//         <select
//           id="email"
//           value={selectedUser._id}
//           onChange={(e) =>
//             setSelectedUser(users.find((user) => user._id === e.target.value))
//           }
//         >
//           {users.map((user) => (
//             <option key={user._id} value={user._id}>
//               {user.email}
//             </option>
//           ))}
//         </select>
//       </div>
//       <div>
//         <label htmlFor="message">Message:</label>
//         <textarea id="message" ref={messageRef} />
//       </div>
//       <button type="submit">Submit</button>
//     </form>
//   );
// };

// export default MailForm;
