import React from "react";
import "./MailHome.scss";
import { AiFillDelete } from "react-icons/ai";

const MailHome = () => {
  const emails = [
    {
      id: 1,
      title: "Hello",
      content: "Hi, How are you?",
      sender: "user1",
      read: false,
    },
    {
      id: 2,
      title: "Important",
      content: "Remember to call me.",
      sender: "user2",
      read: true,
    },
    {
      id: 3,
      title: "Invitation",
      content: "You are invited to the party.",
      sender: "user3",
      read: false,
    },
    {
      id: 4,
      title: "Hello",
      content: "Hi, How are you?",
      sender: "user1",
      read: false,
    },
    {
      id: 5,
      title: "Hello",
      content: "Hi, How are you?",
      sender: "user1",
      read: false,
    },
    {
      id: 6,
      title: "Important",
      content: "Remember to call me.",
      sender: "user2",
      read: true,
    },
    {
      id: 7,
      title: "Invitation",
      content: "You are invited to the party.",
      sender: "user3",
      read: false,
    },
    {
      id: 8,
      title: "Hello",
      content: "Hi, How are you?",
      sender: "user1",
      read: false,
    },
    {
      id: 9,
      title: "Hello",
      content: "Hi, How are you?",
      sender: "user1",
      read: false,
    },
    {
      id: 10,
      title: "Important",
      content: "Remember to call me.",
      sender: "user2",
      read: true,
    },
    {
      id: 11,
      title: "Invitation",
      content: "You are invited to the party.",
      sender: "user3",
      read: false,
    },
    {
      id: 12,
      title: "Hello",
      content: "Hi, How are you?",
      sender: "user1",
      read: false,
    },
    {
      id: 13,
      title: "Hello",
      content: "Hi, How are you?",
      sender: "user1",
      read: false,
    },
    {
      id: 14,
      title: "Important",
      content: "Remember to call me.",
      sender: "user2",
      read: true,
    },
    {
      id: 15,
      title: "Invitation",
      content: "You are invited to the party.",
      sender: "user3",
      read: false,
    },
    {
      id: 16,
      title: "Hello",
      content: "Hi, How are you?",
      sender: "user1",
      read: false,
    },
  ];

  return (
    <div className="mail-list">
      <div className="mail-home">
        <h1>Mailbox</h1>
        <ul className="mail-list">
          {emails.map((email) => (
            <li key={email.id} className="mail-item">
              <p>{email.id}</p>
              <p>{email.title}</p>
              <p>{email.content}</p>
              <p>{email.sender}</p>
              <p>{email.read ? "Read" : "Unread"}</p>
              <p>
                <AiFillDelete />
              </p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default MailHome;
