import React from "react";
import "./MailRead.scss";

const MailRead = () => {
  return <h1>MailRead</h1>;
};

export default MailRead;
