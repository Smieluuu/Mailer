import React from "react";
import "./MailUnread.scss";

const MailUnread = () => {
  return <h1>MailUnread</h1>;
};

export default MailUnread;
