import React from "react";
import "./MailOutgoing.scss";

const MailOutgoing = () => {
  return <h1>MailOutgoing</h1>;
};

export default MailOutgoing;
