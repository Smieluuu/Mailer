const { createProxyMiddleware } = require("http-proxy-middleware");

module.exports = function (app) {
  app.use(
    [
      "/api/userLogin",
      "/api/messages/add",
      "/api/messages/get",
      "/api/messages/delete/:id",
      "/api/get/users",
    ],
    createProxyMiddleware({
      target: "http://localhost:8080",
      changeOrigin: true,
    })
  );
};
