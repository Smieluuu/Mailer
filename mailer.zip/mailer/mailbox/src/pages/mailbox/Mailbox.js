import { React, useEffect, useState, createRef } from "react";
import "../mailbox/Mailbox.scss";
import axios from "axios";
import MailHome from "../../components/mailHome/MailHome";
import Sidebar from "../../components/sidebar/Sidebar";

const Mailbox = () => {
  const [mails, setMails] = useState([]);
  const titleRef = createRef();
  const contentRef = createRef();
  const receiverRef = createRef();

  const sendMailHandler = async (e) => {
    e.preventDefault();

    const title = titleRef.current.value,
      content = contentRef.current.value,
      receiver = receiverRef.current.value;

    if (title.length < 3 || content.length < 3 || receiver.length < 3) {
      return;
    }

    const data = { title, content, receiver };

    console.log(data);

    try {
      const response = await axios.post(
        "/api/add/mail?token=" + sessionStorage.getItem("token"),
        data
      );

      if (response.data.success) {
        getMails();
        document.getElementById("form").reset();
      }
    } catch (error) {
      alert("Error");
    }
  };

  const getMails = async () => {
    const response = await axios.get(
      "/api/get/mails?token=" + sessionStorage.getItem("token")
    );

    if (response.data.success) {
      setMails(response.data.mails);
    }
  };

  useEffect(() => {
    getMails();
  }, []);

  const deleteMail = async (id) => {
    const response = await axios.delete(
      "/api/delete/mail/" + id + "?token=" + sessionStorage.getItem("token")
    );

    if (response.data.success) {
      getMails();
    }
  };

  return (
    <div className="mailbox">
      <Sidebar />
      <MailHome />
    </div>
  );
};

export default Mailbox;
