import "./Mailbox.scss";
import Sidebar from "../.././components/sidebar/Sidebar";
import MailHome from "../../components/mailHome/MailHome";

const Mailbox = () => {
  return (
    <div className="App">
      <Sidebar />
      <MailHome />
    </div>
  );
};

export default Mailbox;
